﻿using System;
using System.Windows.Forms;

namespace Dll1
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Copyright c = new Copyright();
            c.Show();
        }
    }
}
