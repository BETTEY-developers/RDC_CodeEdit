﻿#define Start
#define WM_SETREDRAW
using System;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Drawing;
using System.Xml;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Collections;
using System.Reflection;
using HWND = System.IntPtr;
using APICODE.Function.Code;

namespace Dll1
{
    public partial class WindowAndFunction : Form
    {
        
        XmlDocument xmlDoc = new XmlDocument();
        static public Font font;
        static public Color color = Color.Black;

        StreamReader file;

        int iss = 0;

        private int FileModes { set; get; }

        private bool Try()
        {
            try
            {
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        static public void Plugmain(IRDCEAPIPLUGININTERFACE irapiif) 
        {
            irapiif.AMain();
        }

        private void Cl(Process pro, string name)
        {
            if (Try() == true)
            {
                pro.StartInfo.FileName = @"C:\Windows\System32\cmd.exe";
                pro.StartInfo.UseShellExecute = false;
                pro.StartInfo.RedirectStandardInput = true;
                pro.StartInfo.RedirectStandardOutput = true;
                pro.StartInfo.RedirectStandardError = false;
                pro.StartInfo.CreateNoWindow = true;
                pro.StartInfo.ErrorDialog = true;

                pro.Start();

                pro.StandardInput.WriteLine("gcc " + name + " -o " + name + ".exe &exit");
                pro.StandardInput.AutoFlush = true;

                string output = pro.StandardOutput.ReadToEnd();

                pro.Close();

                log.AppendText(output);
                groupBox1.Visible = true;
                log.Visible = true;
            }
        }

        public WindowAndFunction()
        {
            InitializeComponent();
        }

        public void SaveFile(string filename, string code)
        {
            if (Try() == true)
            {
                StreamWriter filew = new StreamWriter(filename);
                string line;
                while ((line = code) != "\n")
                {
                    filew.WriteLine(line);
                }
            }

        }

        private void ReadFile(string FileName)
        {
            if (Try() == true)
            {
                if (FileName != null)
                {
                    file = new StreamReader(FileName);
                    string line;
                    while ((line = file.ReadLine()) != null)
                    {
                        Code.AppendText(line + "\n");
                    }
                    Code.Visible = true;
                    label2.Visible = false;
                }
            }
        }

        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 生成ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process pro = new Process();

            if (FileModes == 0)
            {
                Cl(pro, openFileDialog1.FileName);
                Start s = new Start();
                s.Show();
            }
            else if (FileModes == 1)
            {
                saveFileDialog1.ShowDialog();
                SaveFile(saveFileDialog1.FileName, Code.Text);
                Cl(pro, saveFileDialog1.FileName);
                FileModes = 0;
                Start s = new Start();
                s.Show();
            }
        }


        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void 文件ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            int a = 0;
            if (a == 1)
            {
                Code.SelectAll();
            }
            openFileDialog1.ShowDialog();
            ReadFile(openFileDialog1.FileName);
            a = 1;
        }

        private void WindowAndFunction_Load(object sender, EventArgs e)
        {
            toolStripMenuItem47.Image = Image.FromFile("exit.png");
            menuStrip3.BackColor = Color.FromArgb(45, 45, 48);
        }

        private void WindowAndFunction_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void 文件ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Code.Visible = true;
            label2.Visible = false;
            FileModes = 1;
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About a = new About();
            a.Show();
            //a.BackColor = Color.Aqua;
        }

        private void menuStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void 生成ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void 颜色主题ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void menuStrip3_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripMenuItem47_MouseEnter(object sender, EventArgs e)
        {
            toolStripMenuItem47.Image = Image.FromFile("arrowexit.png");
        }

        private void toolStripMenuItem47_MouseLeave(object sender, EventArgs e)
        {
            toolStripMenuItem47.Image = Image.FromFile("exit.png");
        }

        private void toolStripMenuItem47_Click(object sender, EventArgs e)
        {
            if (Code.Visible != false)
            {
                QSave s = new QSave(openFileDialog1.FileName, Code.Text);
                s.Show();
            }
            else
            {
                Application.ExitThread();
            }
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {

        }

        private void 保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFile(openFileDialog1.FileName, Code.Text);
        }

        private void Code_TextChanged(object sender, EventArgs e)
        {

        }

        private void 字体颜色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            this.Code.ForeColor = colorDialog1.Color;
        }

        private void toolStripMenuItem1_MouseEnter(object sender, EventArgs e)
        {
            toolStripMenuItem1.BackColor = Color.FromArgb(45, 45, 48);
            
        }

        private void toolStripMenuItem7_MouseMove(object sender, MouseEventArgs e)
        {
            /*if (iss == 1)
            {
                this.Location = e.Location;
            }
            else
            {
                this.Location = this.Location;
            }*/
        }

        private void menuStrip3_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void toolStripMenuItem7_MouseDown(object sender, MouseEventArgs e)
        {
            
        }

        private void toolStripMenuItem7_MouseUp(object sender, MouseEventArgs e)
        {
            
        }

        private void toolStripMenuItem7_Click_1(object sender, EventArgs e)
        {
            sgWH sw = new sgWH(this);
            sw.Show();

        }

        private void 布局设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("尚在开发中");
        }

        private void 插件ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 项目ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void saveFileDialog2_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void 开启系统自带边框ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (iss == 0)
            {
                this.menuStrip3.Visible = false;
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
                开启系统自带边框ToolStripMenuItem.Text = "关闭系统自带边框";
                iss = 1;
            }
            else
            {
                this.menuStrip3.Visible = true;
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                开启系统自带边框ToolStripMenuItem.Text = "开启系统自带边框";
                iss = 0;
            }
        }

        private void 设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SETTINGS settings = new SETTINGS(this);
            settings.Show();
        }

        public void fonts(Font fonts, Color colors)
        {
            Code.Font = fonts;
            Code.ForeColor = colors;
            font = fonts;
            color = colors;
        }

        private void Code_TextChanged_1(object sender, EventArgs e)
        {
            
        }

        private void 文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }

    public class Xml
    {
        public string ARead(XmlNodeList xe, int i, string aname)
        {
            return xe[i].Attributes[aname].Value;
        }
        public int ARead(XmlNodeList xe, int i, string aname, int _)
        {
            return Convert.ToInt32(xe[i].Attributes[aname].Value);
        }
    }

    public interface IRDCEAPIPLUGININTERFACE
    {
        void AMain();
        void AFun();
        void AClass();
    }
    
}
