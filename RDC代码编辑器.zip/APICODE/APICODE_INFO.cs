﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using setting = System.Boolean;
namespace APICODE { }
namespace APICODE.Function.Code
{
    public class DEFOPERATORINFOFUNCTION
    {
        Dll1.WindowAndFunction pros;
        public DEFOPERATORINFOFUNCTION(Dll1.WindowAndFunction pro)
        {
            pros = pro;
        }
        /// <summary>
        /// 获取程序的设置
        /// </summary>
        /// <returns>一个字符串数组</returns>
        public string[] GetExeInfo()
        {
            string[] info = new string[10];
            return info;
        }

        /// <summary>
        /// 获取程序运行时的标题
        /// </summary>
        /// <returns>一个字符串</returns>
        public string GetExeTitle() => pros.Text;
        /// <summary>
        /// 获取程序的图标
        /// </summary>
        /// <returns>Bitmap类型</returns>
        public System.Drawing.Icon GetExeIcon() => pros.Icon;
        /// <summary>
        /// 获取程序的窗口边框类型
        /// </summary>
        /// <returns>BorderStyle类型</returns>
        public FormBorderStyle GetExeFromBorderStyle() => pros.FormBorderStyle;
        /// <summary>
        /// 获取程序窗口有什么控件
        /// </summary>
        /// <returns>ControlCollection类型</returns>
        public Control.ControlCollection GetExeFromControls() => pros.Controls;
        /// <summary>
        /// 获取程序的名字
        /// </summary>
        /// <returns><一个字符串/returns>
        public string GetExeMainWindowName() => pros.Name;
        /// <summary>
        /// 获取输入框内的代码
        /// </summary>
        /// <returns>一个字符串</returns>
        public string GetExeCodeText() => pros.Code.Text;
        /// <summary>
        /// 获取打开的文件的名字
        /// </summary>
        /// <returns>一个字符串</returns>
        public string GetExeOpenFileName() => pros.openFileDialog1.FileName;
        /// <summary>
        /// 获取保存的文件的名字
        /// </summary>
        /// <returns>一个字符串</returns>
        public string GetExeSaveFileName() => pros.saveFileDialog2.FileName;
        /// <summary>
        /// 获取窗口是否启用
        /// </summary>
        /// <returns>一个布尔类型（true（1） 和 false（0））</returns>
        public bool GetExeMainWindowIsEnabled() => ((pros.Enabled == true) ? true : false);
        /// <summary>
        /// 获取窗口的宽度和长度
        /// </summary>
        /// <returns>System.Drawing.Size类型</returns>
        public System.Drawing.Size GetExeMainWindowWidthAndHeigth() => pros.ClientSize;
        /// <summary>
        /// 获取程序配置文件的信息（已弃用）
        /// </summary>
        /// <returns>字符串数组</returns>
        public string[] GetExeSettings() { string[] g = new string[0]; return g; }

        /// <summary>
        /// 设置程序的标题
        /// </summary>
        /// <param name="title">标题</param>
        /// <returns>布尔类型</returns>
        public setting SetExeTitle(string title)
        {
            pros.Text = title;
            return ((pros.Text == title) ? true : false);
        }
        /// <summary>
        /// 设置窗口的边框样式
        /// </summary>
        /// <param name="Style">样式</param>
        /// <returns>布尔类型</returns>
        public setting SetExeFromBorderStyle(System.Windows.Forms.FormBorderStyle Style)
        {
            pros.FormBorderStyle = Style;
            return ((pros.FormBorderStyle == Style) ? true : false);
        }
        /// <summary>
        /// 设置图标
        /// </summary>
        /// <param name="icon">图标</param>
        /// <returns>布尔类型</returns>
        public setting SetExeIcon(System.Drawing.Icon icon)
        {
            pros.Icon = icon;
            return ((pros.Icon == icon) ? true : false);
        }
        /// <summary>
        /// 设置代码
        /// </summary>
        /// <returns>布尔类型</returns>
        public setting SetExeCodeText(string Text)
        {
            pros.Code.Text = Text;
            return ((pros.Code.Text == Text) ? true : false);
        }
        /// <summary>
        /// 设置打开的文件的名称
        /// </summary>
        /// <param name="Name">名称</param>
        /// <returns>布尔类型</returns>
        public setting SetExeOpenFileName(string Name)
        {
            return false;
        }
        /// <summary>
        /// 设置保存的文件的名称
        /// </summary>
        /// <param name="Name">名称</param>
        /// <returns>布尔类型</returns>
        public setting SetExeSaveFileName(string Name)
        {
            return false;
        }
        /// <summary>
        /// 设置窗口的启用状态
        /// </summary>
        /// <param name="IsEn">是否启用</param>
        /// <returns>布尔类型</returns>
        public setting SetExeMainWindowEnabled(bool IsEn)
        {
            pros.Enabled = IsEn;
            return ((pros.Enabled == IsEn) ? true : false);
        }
        /// <summary>
        /// 设置程序的配置文件（已弃用）
        /// </summary>
        /// <param name="Name">名称</param>
        /// <returns>布尔类型</returns>
        public setting SetExeSetting(string Name)
        {
            return false;
        }
    }
}
