﻿/*
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dll1;
using RDCAPIPLUGININTERFACE.Define;

namespace RDCAPIPLUGININTERFACE
{
    interface IRDCEDITERPLUG
    {
        
    }
}
*/