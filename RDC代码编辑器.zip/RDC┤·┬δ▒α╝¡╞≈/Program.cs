﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dll1;
using APICODE.Function.Code;
using System.Reflection;

namespace RDC代码编辑器
{
    class Program
    {
        private static WindowAndFunction waf;
        private static APICODE.Function.Code.DEFOPERATORINFOFUNCTION code;
        [STAThread]
        private static void Main(string[] args)
        {
            Application.SetCompatibleTextRenderingDefault(false);
            DEF();
            Application.EnableVisualStyles();
            Console.WriteLine(code.GetExeTitle());
            Console.WriteLine(code.SetExeTitle(code.GetExeTitle() + $" - {args[0]}"));
            
            Application.Run(waf);
        }

        private static void DEF()
        {
            waf = new WindowAndFunction();
            code = new APICODE.Function.Code.DEFOPERATORINFOFUNCTION(waf);
        }
    }
}
