﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dll1
{
    public class Startone : WindowAndFunction
    {
        public void Load1()
        {
            WindowAndFunction waf = new WindowAndFunction();
            waf.Show();
        }
        
    }
}
