﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Dll1
{
    class WRProject
    {
        private string projectname;
        string prne { get{return projectname;} }
        public void PjcLoad(string name);
        public void WritePjc();/*必须调用PjcLoad函数*/
        public int ProjectID();
        public void ReadPjc();
        public void WritePjc();
    }

    class RProject : WRProject
    {
    }
}
