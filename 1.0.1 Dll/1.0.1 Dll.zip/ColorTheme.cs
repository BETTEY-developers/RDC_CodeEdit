﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dll1
{
    public partial class ColorTheme : Form
    { 
        private bool buttonrtn;
        public bool buttonRtn { 
            get
            {
                return buttonrtn;
            }
        }

        public ColorTheme()
        {
            InitializeComponent();
        }

        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            buttonrtn = false;
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            buttonrtn = true;
            Close();
        }
    }
}
